IF  EXISTS (SELECT name FROM sys.databases WHERE name = N'@token')
DROP DATABASE @token
GO

IF EXISTS (SELECT * FROM sys.syslogins WHERE name = N'@token')
DROP LOGIN @token
GO

CREATE DATABASE @token
GO

USE @token
GO

CREATE LOGIN @token WITH PASSWORD = '@token', CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

CREATE USER @token FOR LOGIN @token
GO

EXEC sp_addrolemember db_owner, @token

