﻿using System;
using System.Xml.Linq;

namespace Bechtel.CSVDataLayer.API
{
  public class Equipment
  {
    public string Tag { get; set; }
    public string PumpType { get; set; }
    public string PumpDriverType { get; set; }
    public Double DesignTemp { get; set; }
    public Double DesignPressure { get; set; }
    public Double Capacity { get; set; }
    public Double SpecificGravity { get; set; }
    public Double DifferentialPressure { get; set; }
  }

  public class Instrument 
  {
    public string Tag { get; set; }
    public string Description { get; set; }
    public string NominalDiameter { get; set; }
    public string InsulType { get; set; }
    public string InsulPurpose { get; set; }
    public string InsulThick { get; set; }
  }

  public class PipeRun 
  {
    public string Tag { get; set; }
    public string Description { get; set; }
    public string NominalDiameter { get; set; }
    public string InsulType { get; set; }
    public string InsulPurpose { get; set; }
    public string InsulThick { get; set; }
    public string OperFluidCode { get; set; }
    public string PipingMaterialsClass { get; set; }
  }

  public class PipingComp
  {
    public string Tag { get; set; }
    public string Description { get; set; }
    public string NominalDiameter { get; set; }
    public string InsulType { get; set; }
    public string InsulPurpose { get; set; }
    public string InsulThick { get; set; }
  }
}
