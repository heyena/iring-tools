﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using org.iringtools.library;
using org.iringtools.utility;
using System.ComponentModel;
using org.iringtools.library.events;
using System.Collections.Specialized;

namespace iRINGTools.Web.Models
{
  public class AdapterManagerDAL
  {
    public event EventHandler<EventArgs> OnDataArrived;
    private string _hibernateServiceUri;
    private string _adapterServiceUri;

    public AdapterManagerDAL(NameValueCollection settings)
    {
      _adapterServiceUri = settings["AdapterServiceUri"];
      _hibernateServiceUri = settings["NHibernateServiceUri"];
    }

    public DataObjects GetDbObjects(string projectName, string applicationName)
    {
      string relativeUri = String.Format("/{0}/{1}/objects",
         projectName,
         applicationName
       );

      Uri address = new Uri(_hibernateServiceUri + relativeUri);

      WebClient webClient = new WebClient();
     // webClient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(OnGetDbObjectCompletedEvent);
      string result = webClient.DownloadString(address);
      if (result != string.Empty)
      {
        return result.DeserializeDataContract<DataObjects>();
      }
      else
      {
        return null;
      }
    }

  }

}