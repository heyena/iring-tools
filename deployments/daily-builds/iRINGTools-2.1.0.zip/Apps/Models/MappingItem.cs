﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using org.iringtools.mapping;

namespace iRINGTools.Web.Models
{
  public class MappingItem
  {
    public NodeType NodeType { get; set; }
    public GraphMap GraphMap { get; set; }
    public ClassMap ClassMap { get; set; }
    public TemplateMap TemplateMap { get; set; }
    public RoleMap RoleMap { get; set; }
    public ValueMap ValueMap { get; set; }
  }

  public enum NodeType
  {
    Class,
    TemplateDefinition,
    TemplateQualification,
    RoleDefinition,
    RoleQualification,
    GraphMap,
    ClassMap,
    TemplateMap,
    RoleMap,
    ValueMap,
    ValueList
  }
}