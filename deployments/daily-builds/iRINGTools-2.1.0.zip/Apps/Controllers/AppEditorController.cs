﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace org.iringtools.client.Controllers
{
    public class RefDataEditorController : Controller
    {
        //
      // GET: /RefDataEditor/

        public ActionResult Index()
        {
            return View();
        }

    }
}
