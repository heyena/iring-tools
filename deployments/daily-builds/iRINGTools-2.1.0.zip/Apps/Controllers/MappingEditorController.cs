﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Collections.Specialized;
using System.Configuration;

namespace org.iringtools.client.Controllers
{
    public class MappingEditorController : Controller
    {

          NameValueCollection _settings = null;
    string _adapterServiceURI = String.Empty;
    string _refDataServiceURI = String.Empty;

    public MappingEditorController()
    {
      _settings = ConfigurationManager.AppSettings;
      _adapterServiceURI = _settings["AdapterServiceUri"];
      _refDataServiceURI = _settings["ReferenceDataServiceUri"];
    }  
        //
        // GET: /MappingEditor/

        public ActionResult Index()
        {
            return View();
        }


    }
}
