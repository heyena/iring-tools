﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("iringug.org")]
[assembly: AssemblyProduct("iRINGTools SDK")]
[assembly: AssemblyCopyright("Copyright © 2011, iringug.org")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("2.1.0.2977")]
[assembly: AssemblyFileVersion("2.1.0.2977")]
