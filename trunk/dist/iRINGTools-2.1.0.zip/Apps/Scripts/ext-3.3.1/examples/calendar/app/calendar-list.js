/*!
 * Ext JS Library 3.3.1
 * Copyright(c) 2006-2010 Sencha Inc.
 * licensing@sencha.com
 * http://www.sencha.com/license
 */
var calendarList = {
    "calendars":[{
        "id":1,
        "title":"Home"
    },{
        "id":2,
        "title":"Work"
    },{
        "id":3,
        "title":"School"
    }]
};
